# Weather App

## Installation

To install the dependencies:

> npm install

## Running locally

To the run the app locally in development enviroment:

> npm run dev

Add your API key in Forcast.tsx and Weather.tsx

## How to use App

After running dev enviroment just the link in the terminal to view the app

if your using the deployed link and there is a network error showing go to site setting and allow insecure content for the site

# Deployed Link

https://8lacknwhite.github.io/propacity_proj/
