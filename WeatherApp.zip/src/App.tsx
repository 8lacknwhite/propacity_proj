import "./App.css";
import Homepage from "./View/Homepage";

function App() {
  return (
    <>
      <Homepage />
    </>
  );
}

export default App;
